
const productsDiv = document.getElementById("products");

db.collection("products").onSnapshot(snapshot => {
  productsDiv.innerHTML = "";
  snapshot.forEach(doc => {
    const p = doc.data();
    productsDiv.innerHTML += `
      <div class="product">
        <img src="${p.image}" width="100%">
        <h3>${p.name}</h3>
        <p>Rs ${p.price}</p>
      </div>
    `;
  });
});
